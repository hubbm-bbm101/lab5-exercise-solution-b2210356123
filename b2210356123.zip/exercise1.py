n = int(input("Please enter a number: "))
sum_of_odd = 0
sum_of_even = 0
count = 0
for i in range(1,n+1):
    if(i%2 == 0):
        sum_of_even = sum_of_even + i
        count = count + 1
    else:
        sum_of_odd = sum_of_odd + i
print("Odd numbers sum:",sum_of_odd)
print("Average of even numbers:",int(sum_of_even/count))
