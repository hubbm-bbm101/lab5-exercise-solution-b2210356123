import random 
number = random.randint(0,100)
guess = int(input("Make a guess:"))
while guess != number:
    if guess > number:
        print("Decrease your guess")
    else:
        print("Increase your guess")
    guess = int(input("Try again:"))
print("You guessed true!")