def check(text):
    if("@" in text and "." in text):
        return True
    else:
        return False

mail = input("Please enter your mail address: ")
if(check(mail)):
    print("Mail address is valid")
else:
    print("Mail address is not valid")